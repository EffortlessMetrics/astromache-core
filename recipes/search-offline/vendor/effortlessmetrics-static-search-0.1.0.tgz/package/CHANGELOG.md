# Changelog

## 0.1.0 — unpublished extraction candidate

- Shared static-index single-flight loading, content-version coherency and invalidation.
- Correlated worker startup/search, aborts, timeouts, stale-response isolation and teardown.
- Shared worker endpoint and structurally compatible backend fallback orchestration.
- Consumer engines, ranking, schema, routes, cache policy and rich shards remain local.

Unpublished candidate review repairs: generation-local startup transport cleanup prevents invalidation from disposing a replacement worker; search timeout/abort includes shared fallback construction. Regression contracts also verify sibling construction remains shared. Published interaction archives are unchanged.
