# Static Search

`@effortlessmetrics/static-search@0.1.0` is an unpublished ESM package for shared
static-index and worker lifecycle mechanics. It has no runtime dependencies.

The consumer supplies its serialized index, version identity, fetch policy,
engine, query options, ranking, result schema, routes and caches. The package
owns single-flight index loading, generation invalidation, abort/timeout cleanup,
worker startup, correlated requests, coherent versions, stale replies, teardown
and fallback orchestration. It contains no MiniSearch, Preact, site globals,
analytics, persistent storage or LRU policy.

## API

- `createStaticIndexLoader<T>({load(signal), expectedVersion?, timeoutMs?})`:
  `load({signal?})`, `invalidate()`, `dispose()`. The load callback returns
  `{version: string, data: T}`. Failed/stale loads are not cached. A caller's
  abort cancels its wait, not another caller's shared load; invalidate/dispose
  abort the owned load. The consumer derives the version from exact index
  bytes or a verified immutable release fingerprint. Schema versions such as
  "MiniSearch format 2" are not content identity.
- `createWorkerTransport<Init, Options, Answer>({createWorker, timeoutMs?})`:
  `init(payload,version,{signal?,timeoutMs?})`, `search(query,options,request?)`,
  `dispose()`. Only responses matching both request ID and index version settle
  requests. Late replies do not satisfy newer work. Worker errors reject all
  pending requests and terminate the owned worker.
- `installStaticSearchWorker(scope,{initialize,search})`: installs protocol
  `static-search/1`; returns teardown. Initialize receives payload and
  `{signal,version}`, and returns the actual loaded `{version}` receipt. Search
  receives query, consumer options and that context. Consumers check signals
  before committing asynchronous engine state. Teardown/initialization generation
  changes suppress late responses. Other protocols are ignored.
- `createStaticSearchBackend({index,createWorker?,workerInit?,createFallback,
  getAllDocuments?,initTimeoutMs?,searchTimeoutMs?})`: exposes `init`, `isReady`,
  `search`, `getAllDocuments`, `invalidate`, `dispose`. Supply an answer such as
  `{results: MyResult[]}` and your options type for structural compatibility
  with TypeAnywhereSearch's backend port. No interaction-package import is needed.
  Worker init defaults to the exact `{version,data}` snapshot, avoiding a second
  fetch that could observe different bytes. Fallback engines are created only
  when needed and shared by concurrent fallback requests. Optional snapshot
  `getAllDocuments` avoids building a main-thread engine merely to browse.

A worker failure falls back; caller abort/disposal/stale generation does not.
An unavailable index rejects instead of masquerading as successful no-results.
Successful empty engine results remain authoritative. Call `invalidate()` to
upgrade snapshots, then initialize again. Consumers own result cancellation and
UI admission; the transport does not invent a latest-query ranking policy.

## Engine recipe

```ts
const index = createStaticIndexLoader<MyIndex>({
  load: async signal => {
    const response = await fetch('/my-index.json', {signal});
    if (!response.ok) throw new Error(`Index HTTP ${response.status}`);
    const bytes = await response.text();
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(bytes));
    const version = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2,'0')).join('');
    return {version, data: JSON.parse(bytes)};
  },
});
```

Keep credentials/cache policy and expected release hash in this callback/config.
A consumer worker builds its engine from the transmitted snapshot and returns
that version after checking its signal. The worker URL remains a literal native
`new Worker(new URL('./worker.ts', import.meta.url), {type:'module'})` in the
consumer so its bundler sees the source. Engines and corpus generation are not
exported by this package.

## Verify and release

Node24.19.0 / pnpm10.23.0 / native TypeScript7.0.2 are the qualified tools.
`pnpm install --frozen-lockfile && pnpm verify` compiles declarations, runs
lifecycle/race/fallback tests, packs a clean archive, checks exclusions/licenses,
and runs those tests plus strict types from a fresh installed consumer.
Browser proof belongs to the actual personal and Carcinisation consumers.

`pnpm pack --pack-destination release-artifacts` prepares an immutable archive.
An authorized reviewer may use `npm publish --dry-run --ignore-scripts <archive>`.
Actual registry publication, credentials and visibility are separate owner actions.
Upgrade/rollback restore archive, receipt, manifest, lock and consumer worker
adapters together, then repeat packed seam, types and browser/offline acceptance.

Owner-authored source is newly extracted/reworked from the canonical package and
its two consumers under Steven Zimmerman's settled MIT OR Apache-2.0 grant.
The root interaction package remains separately versioned and its published
bytes are unchanged. Third-party engines remain consumer dependencies with their
own licenses. This package ships neither engines nor their implementations.

Per-call timeoutMs bounds the caller's wait for shared loading/initialization and fallback queries without cancelling other callers. The loader's configured timeout aborts its owned fetch; worker deadlines cancel the correlated worker request.
